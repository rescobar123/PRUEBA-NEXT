<?php return array (
  'find-pelis' => 'App\\Http\\Livewire\\FindPelis',
  'show-pelis' => 'App\\Http\\Livewire\\ShowPelis',
);