<a href="/">
  <img width="50px;" src="https://img2.freepng.es/20180323/ape/kisspng-art-film-logo-cinema-clip-art-movie-logo-cliparts-5ab587fb1000c4.1651552415218462670656.jpg" />
</a><?php /**PATH C:\xampp\htdocs\PRUEBA-NEXT\ppelis\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>