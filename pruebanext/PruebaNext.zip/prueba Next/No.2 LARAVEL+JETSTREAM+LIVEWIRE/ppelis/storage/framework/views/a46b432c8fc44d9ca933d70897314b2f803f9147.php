<div>

     <?php $__env->slot('header'); ?> 
        <h2 class="font-bold text-xl text-blue-800 leading-tight">
            Ppelis
           
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="max-w-7x1 mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="px-6 py-4">
            <label>Buscar mis peliculas favoritas</label>
            <input type="text" wire:model="search">
        </div>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table','data' => []]); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Poster
                        </th>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            ID
                        </th>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Titulo
                        </th>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Anio
                        </th>
                        <th scope="col"
                            class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Ratings
                        </th>

                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $pelis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4\">
                            <div class="flex-shrink-0 h-40 w-40">
                                <img class="h-40 w-40 rounded-full" src=" <?php echo e($peli->poster); ?>" alt="">
                            </div>
                            </td>
                        <td class="px-6 py-4\">
                            <div class="text-sm text-gray-900">
                                <?php echo e($peli->imdbID); ?>

                            </div>
                        </td>
                        <td class="px-6 py-4 ">
                            <div class="text-sm text-gray-900">
                                <?php echo e($peli->title); ?>

                            </div>
                        </td>
                        <td class="px-6 py-4 ">
                            <div class="text-sm text-gray-900">
                                <?php echo e($peli->year); ?>

                            </div>
                        </td>
                        <td class="px-6 py-4 ">
                            <div class="text-sm text-gray-900">
                                <?php echo e($peli->ratings); ?>

                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\PRUEBA-NEXT\ppelis\resources\views/livewire/show-pelis.blade.php ENDPATH**/ ?>