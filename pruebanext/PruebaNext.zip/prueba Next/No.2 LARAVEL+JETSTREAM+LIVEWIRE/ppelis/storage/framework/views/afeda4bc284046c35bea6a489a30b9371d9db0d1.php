<div>
    <h1>Hola mundo dentro de la carpeta nat</h1>
</div>
<?php /**PATH C:\xampp\htdocs\PRUEBA-NEXT\ppelis\resources\views/livewire/nat/show-pelis.blade.php ENDPATH**/ ?>